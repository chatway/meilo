export default [
    { name: 'tasks', path: '/tasks' },
    { name: 'task', path: '/task/:id' },
    { name: 'edit', path: '/edit/:id' },
    { name: 'add', path: '/add' }
]